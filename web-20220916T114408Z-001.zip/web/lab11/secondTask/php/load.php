<?php 
$a = file_get_contents("../txt/load.txt");
echo $a;
