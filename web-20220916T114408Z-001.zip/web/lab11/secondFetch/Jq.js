/*Slider*/

$(function () {
    var left = 0,
        timer;
    autoSlider();

    function autoSlider() {
        timer = setTimeout(function () {
            var slide = $('.slide');
            left -= 600;
            if (left < -1200) {
                left = 0;
                clearTimeout(timer);
            }
            slide.css('margin-left', left + 'px');
            autoSlider();
        }, 1500);
    }

    /*Load more*/
    
    $(".Btn").click(function () {
        var a = '<div class="row text-center">';
        var count = 0;

        for (var i = 1; i <= 4; i++) {
            a += '<div class = "col-xs-12 col-sm-3 blockPhone"><h5>Nokia ' + i + '</h5>' + '<img src = "images/phone' + i + '.png" class = "img img-responsive"> <button class = "btn"> details</button></div >';

        }
        a += '</div>';
        $(".Btn").before(a);
    });

    /*list collapse*/
    
    var list = $(".list-group-item");

    for (var i = 0; i < list.length; i++) {
        list.eq(i).attr("data-opened", false);

    }

    $(list).click(function () {
        if ($(this).attr("data-opened") === "false") {
            $(this).after("<div class='" + $(this).text() + "'>Hello world!</div>");
            var s = $(this).text();
            $(this).attr("data-opened", true);
        } 
        else {
            $(this).attr("data-opened", "false");
            $("." + $(this).text()).remove();
            console.log($(this).text());

        }
        return false;
    });

});
