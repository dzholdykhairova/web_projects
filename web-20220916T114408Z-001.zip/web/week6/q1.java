import java.util.*;
public class q1 {
	public static void main(String []args){
		int i = 0;
		Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
		while(i != n){
			System.out.println(fibonaci(i));
			i++;
		}
	}
	public static int fibonaci(int n) {
		if(n == 1){
			return 1;
		}
		else if (n == 0){
			return 0;
		}

		else {
			int in = fibonaci(n - 1) + fibonaci(n - 2);  
			return in;
		}
	}
}