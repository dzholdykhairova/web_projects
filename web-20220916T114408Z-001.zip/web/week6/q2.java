import java.util.*;
public class q2 {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      int n = sc.nextInt();
      doTowers(n, 'A', 'B', 'C');
   }
   public static void doTowers(int n, char from, char other, char to) {
      if (n == 1) {
         System.out.println("Disk 1 from " + from + " to " + to);
      } else {
         doTowers(n - 1, from, to, other);
         System.out.println("Disk " + n + " from " + from + " to " + to);
         doTowers(n - 1, other, from, to);
      }
   }
}