import java.util.*; 
public class q1 { 
	public static Scanner sc = new Scanner(System.in); 
	public static int n,age,x,id; 
	public static String name,surname; 
	public static Queue<Person> quque = new LinkedList<Person>(); 
	public static void main(String []args){ 
		MainMenu();
	} 
	public static void MainMenu(){
		System.out.println("New Person - 1"); 
		System.out.println("Rename Person - 2"); 
		System.out.println("Remove Person - 3"); 
		System.out.println("Persons's list - 4"); 
		n = sc.nextInt(); 
		if(n == 1){ 
			AddPerson(quque);
		} 
		else if(n == 2){
			RenamePersons(quque);			} 
		else if(n == 3){
			DeletePerson(quque);
		} 
		else if (n == 4){
			PersonsList(quque,true); 
		}
	}
	public static void AddPerson(Queue<Person> q){
		System.out.println("Enter the name"); 
		name = sc.next(); 
		System.out.println("Enter the surname"); 
		surname = sc.next(); 
		System.out.println("Enter the age"); 	
		age = sc.nextInt(); 
		quque.add(new Person(name,surname,age));
		MainMenu();
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       }
	public static void DeletePerson(Queue<Person> quque){
		PersonsList(quque,false); 
		System.out.println(); 
		System.out.println(); 
		System.out.println("Enter Person id"); 
		id = sc.nextInt(); 
		Person element; 
		for(int i = 0; i < quque.size();i++){ 
			if(i+1 == id){ 
				element = quque.remove(); 
			} 
			else{ 
				quque.add(quque.remove()); 
			} 
		}
		MainMenu(); 
	}
	public static void PersonsList(Queue<Person> q,boolean t){ 
		Person element;
		if(q.size() == 0){
			System.out.println("The is No Persons");
		}
		for(int i = 0; i < q.size(); i++){ 
			element = q.peek(); 
			System.out.println((i + 1) + ")" + element.name + " " + element.surname + " " + element.age); 
			q.add(q.remove());
		} 
		if(t){
			System.out.println();
			System.out.println();
			MainMenu();
		}
	} 
	public static void RenamePersons(Queue<Person> quque){
		String name,surname; 
			int n,age,x,id; 
			Scanner sc = new Scanner(System.in);
			PersonsList(quque,false); 
			System.out.println(); 
			System.out.println(); 
			System.out.println("Enter Person id"); 
			id = sc.nextInt(); 
			Person element; 
			if(quque.size() == 0){
				MainMenu();
			} 
			for(int i = 0; i < quque.size();i++){ 
				if(i+1 == id){ 
					System.out.println("Enter the choice"); 
					System.out.println("Name - 1"); 
					System.out.println("surname - 2"); 
					System.out.println("age - 3"); 
					System.out.println("Exit - 4"); 
					element = quque.remove(); 
					x = sc.nextInt(); 
					if(x == 1){ 
						System.out.print("Enter the Name : "); 
						name = sc.next(); 
						element.setName(name); 
						quque.add(element); 
					} 
					else if(x == 2){ 
						System.out.print("Enter the Surname : "); 
						surname = sc.next(); 
						element.setSurname(surname); 
						quque.add(element); 
					} 
					else if(x == 3){ 
						System.out.print("Enter the  age: "); 
						age = sc.next(); 
						element.setSurname(age); 
							quque.add(element); 
					}
					else if (x == 4){
						quque.add(element);
						MainMenu();
					} 
				} 
			else{ 
					quque.add(quque.remove()); 
			} 
		}
		RenamePersons(quque); 
	}
} 