<?php
echo file_get_contents("../txt/".$_GET["val"].".txt");
