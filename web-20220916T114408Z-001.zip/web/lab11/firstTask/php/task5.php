<?php

    if (isset($_POST['num1']) && $_POST['num1']!='' && isset($_POST['num2']) && $_POST['num2']!='') {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        echo "SUM ".($num1+$num2);
    }
    else {
        echo 'Ошибка! Введите числа';
    }


?>
