<?php
$result = $_POST["first"] + $_POST["second"];
echo $result;
