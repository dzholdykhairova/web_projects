<?php
$year = $_POST["val"];
if(strlen($year) <= 4&& strlen($year) >= 1 && $year < date('Y')){
        echo date('Y') - $_POST["val"];
}
else {
    echo "Write currect time";
}
