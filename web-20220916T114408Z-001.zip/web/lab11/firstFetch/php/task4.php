<?php
echo file_get_contents("../txt/".$_POST["val"].".txt");
