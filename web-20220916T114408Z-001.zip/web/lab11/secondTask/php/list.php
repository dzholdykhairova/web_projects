<?php 
$a = file_get_contents("../txt/list.txt");
$b = $_GET['in'];
$c = file_get_contents('../txt/list2.txt');
$d=$a . "" . $b . "" . $c;
echo $d;
