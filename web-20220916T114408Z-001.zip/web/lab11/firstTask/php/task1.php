<?php 
$a = file_get_contents("../txt/testfile.txt");
echo $a;
