import java.util.*; 
public class stack { 
	public static Scanner sc = new Scanner(System.in); 
	public static int n,age,x,id; 
	public static String name,surname; 
	public static Stack<Person> stack = new Stack<Person>(); 
	public static void main(String []args){ 
		MainMenu();
	}
	public static void MainMenu(){
		System.out.println("New Person - 1"); 
		System.out.println("Rename Person - 2"); 
		System.out.println("Remove Person - 3"); 
		System.out.println("Persons's list - 4"); 
		n = sc.nextInt(); 
		if(n == 1){
			AddPerson(stack);
		} 
		else if(n == 2){
			RenamePersons(stack);				
		} 
		else if(n == 3){
			DeletePerson(stack);
		} 
		else if (n == 4){
			ShowPersons(stack,true); 
		}
	}
	public static void AddPerson(Stack<Person> q){
		System.out.println("Enter the name");
		name = sc.next();
		System.out.println("Enter the surname"); 
		surname = sc.next(); 
		System.out.println("Enter the age"); 	
		age = sc.nextInt(); 
		stack.push(new Person(name,surname,age));
		MainMenu();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
	public static void DeletePerson(Stack<Person> stack){
		ShowPersons(stack,false); 
		System.out.println("Enter Person id"); 
		id = sc.nextInt(); 
		RemoveStackElement(stack,id);
		MainMenu(); 
	}
	public static void ShowPersons(Stack<Person> q,boolean t){ 
		Person element;
		if(q.size() == 0){
			System.out.println("Empty\n");
			if(t){
				MainMenu();
			}
		}
		showStackElement(stack);
		if(t){
			MainMenu();
		}
	} 
	public static void RenamePersons(Stack<Person> stack){
		String name,surname; 
		int n,age,x,id; 
		Scanner sc = new Scanner(System.in);
		ShowPersons(stack,false); 
		System.out.println("Enter Person id"); 
		id = sc.nextInt(); 
		Person element;
		RenameStackElement(stack,id); 
		RenamePersons(stack); 
	}
	public static void showStackElement(Stack<Person> stack) {
	  Person element;
	  element = stack.peek();
	  System.out.println(stack.size() +")" + element.name + " " + element.surname + " " + element.age);
	  Person x = stack.pop();
	  try {
	  	if(stack.size() != 0)
	    showStackElement(stack);
	  } finally {
	    stack.push(x);
	  }
	}
	public static void RemoveStackElement(Stack<Person> stack, int index) {
	  if (index == 1) {
	    stack.pop();
	    MainMenu();
	  }
	  Person x = stack.pop();
	  try {
	  	if(stack.size() != 0)
	    	RemoveStackElement(stack, index - 1);
	  } finally {
	    stack.push(x);
	  }
	}public static void RenameStackElement(Stack<Person> stack, int index) {
	  if (index == 1) {
	  	Person element;
	    System.out.println("Rename Name - 1"); 
		System.out.println("Rename surname - 2"); 
		System.out.println("Rename age - 3"); 
		System.out.println("Exit - 4"); 
		element = stack.peek(); 
		x = sc.nextInt(); 
		if(x == 1){ 
			System.out.print("Enter the Name : "); 
			name = sc.next(); 
			element.setName(name); 
		} 
		else if(x == 2){ 
			System.out.print("Enter the Surname : "); 
			surname = sc.next(); 
			element.setSurname(surname);
		} 
		else if(x == 3){ 
			System.out.print("Enter the age : "); 
			age = sc.nextInt(); 
			element.setAge(age);	 
		}
		else if (x == 4){
			MainMenu();
		}
	  }
	  Person y = stack.pop();
	  try {
	  	if(stack.size() != 0)
	    	RenameStackElement(stack, index - 1);
	  } finally {
	    stack.push(y);
	  }
	}
} 