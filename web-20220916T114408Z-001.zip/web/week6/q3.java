import java.util.*;
public class q1 {
	public static void main(String []args){
		int i = 0;
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int m = sc.nextInt();
		System.out.println("The Greatest Common Divisor of" + n + " & " + m + " is " + gcd(n,m));
	}
	public static long gcd(long a, long b) { 
		if (b==0) 
    		return a;
  		else
    		return gcd(b, a % b);
	}
}